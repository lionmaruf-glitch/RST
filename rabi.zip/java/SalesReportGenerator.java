import java.sql.*;
import java.io.*;
import java.time.LocalDate;

public class SalesReportGenerator {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/rst_erp?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASS = "";

    public static void main(String[] args) {
        String outputFile = "sales_report_" + LocalDate.now() + ".csv";
        String query = "SELECT s.invoice_no, s.sale_date, COALESCE(c.name,'Walk-in') AS customer, " +
                       "s.subtotal, s.vat, s.grand_total, s.payment_method " +
                       "FROM sales s LEFT JOIN customers c ON s.customer_id = c.id " +
                       "ORDER BY s.sale_date DESC";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query);
             FileWriter fw = new FileWriter(outputFile);
             BufferedWriter bw = new BufferedWriter(fw)) {

            bw.write("Invoice No,Sale Date,Customer,Subtotal,VAT,Grand Total,Payment Method\n");
            while (rs.next()) {
                bw.write(String.format("%s,%s,%s,%.3f,%.3f,%.3f,%s\n",
                        rs.getString("invoice_no"),
                        rs.getTimestamp("sale_date"),
                        rs.getString("customer"),
                        rs.getBigDecimal("subtotal"),
                        rs.getBigDecimal("vat"),
                        rs.getBigDecimal("grand_total"),
                        rs.getString("payment_method")));
            }
            System.out.println("✅ Report generated: " + outputFile);
        } catch (SQLException | IOException e) {
            System.err.println("❌ Error: " + e.getMessage());
        }
    }
}